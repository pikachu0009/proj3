ECE748 Project3 (Group 6)

1)To acheive coverage closure, run all the 5 tests included and then get the result from the merged ucdbs.
2)All the tests are listed in the sim/testlist file
3)All the ucdb files and the testplan is included in the CoverageDetails folder
4)To run a single test, use the command "make cli TEST_NAME=name_of_the_test", this will also generate the ucdb for that particular test and merge it with the testplan ucdb.
  -To acheive full coverage USE THE FOLLOWING COMMANDS in any order:
      - make cli TEST_NAME=test_top               {This will run the test_top and then generate its ucdb, and merge it with testplan.ucdb}
	  - make cli TEST_NAME=alu_test               {This will run the alu_test and then generate its ucdb, and merge it with testplan.ucdb in}
	  - make cli TEST_NAME=memory_test            {This will run the memory_test and then generate its ucdb, and merge it with testplan.ucdb}
	  - make cli TEST_NAME=control_test           {This will run the control_test and then generate its ucdb, and merge it with testplan.ucdb}
	  - make cli TEST_NAME=alu_mem_test           {This will run the alu_mem_test and then generate its ucdb, and merge it with testplan.ucdb}
	  
	After you run all these 5 commands, all the tests will have merged their ucdbs with the testplan ucdb and we can get the maximun coverage.
	
5)The bug report is included in BugReport folder.
6)The transcripts for all the tests used to acheive coverage closure are included in Transcript folder.